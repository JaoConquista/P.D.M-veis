
fun main() {
    val nomes = arrayOf(
        "João Silva Pereira",
        "Maria Santos Oliveira",
        "Pedro Almeida Carvalho",
        "Ana Rodrigues Gonçalves",
        "Carlos Fernandes Costa",
        "Isabel Pereira Ribeiro",
        "Luís Almeida Teixeira",
        "Lúcia Santos Barbosa",
        "Ricardo Gonçalves Pereira",
        "Marta Rodrigues Ferreira",
        "António Teixeira Oliveira",
        "Sofia Fernandes Costa",
        "Fernando Silva Almeida",
        "Catarina Pereira Ribeiro",
        "Miguel Almeida Carvalho",
        "Teresa Gonçalves Rodrigues",
        "Manuel Fernandes Teixeira",
        "Beatriz Ribeiro Pereira",
        "Hugo Costa Almeida",
        "Vera Santos Gonçalves",
        "Paulo Alves Ribeiro",
        "Cláudia Mendes Silva",
        "André Sousa Oliveira",
        "Helena Costa Rodrigues",
        "Nuno Pereira Almeida",
        "Inês Gonçalves Teixeira",
        "Fábio Alves Ribeiro",
        "Sara Fernandes Costa",
        "Gonçalo Silva Oliveira",
        "Lara Rodrigues Ferreira",
        "José Pereira Almeida",
        "Carolina Santos Ribeiro",
        "Rui Teixeira Oliveira",
        "Ingrid Fernandes Costa",
        "Guilherme Almeida Barbosa",
        "Tatiana Oliveira Silva",
        "Rafael Carvalho Pereira",
        "Daniela Costa Rodrigues",
        "Leandro Santos Ribeiro",
        "Clara Oliveira Almeida",
        "Bruno Pereira Costa",
        "Mariana Rodrigues Gonçalves",
        "Tiago Silva Almeida",
        "Isabela Ribeiro Teixeira",
        "Davi Almeida Costa",
        "Larissa Teixeira Gonçalves",
        "Marcelo Fernandes Pereira",
        "Fernanda Santos Oliveira",
        "Vinícius Pereira Costa",
        "Lucas Alves Ribeiro"
    )

    val sexos = arrayOf(
        "masculino", // João Silva Pereira
        "feminino",  // Maria Santos Oliveira
        "masculino", // Pedro Almeida Carvalho
        "feminino",  // Ana Rodrigues Gonçalves
        "masculino", // Carlos Fernandes Costa
        "feminino",  // Isabel Pereira Ribeiro
        "masculino", // Luís Almeida Teixeira
        "feminino",  // Lúcia Santos Barbosa
        "masculino", // Ricardo Gonçalves Pereira
        "feminino",  // Marta Rodrigues Ferreira
        "masculino", // António Teixeira Oliveira
        "feminino",  // Sofia Fernandes Costa
        "masculino", // Fernando Silva Almeida
        "feminino",  // Catarina Pereira Ribeiro
        "masculino", // Miguel Almeida Carvalho
        "feminino",  // Teresa Gonçalves Rodrigues
        "masculino", // Manuel Fernandes Teixeira
        "feminino",  // Beatriz Ribeiro Pereira
        "masculino", // Hugo Costa Almeida
        "feminino",  // Vera Santos Gonçalves
        "masculino", // Paulo Alves Ribeiro
        "feminino",  // Cláudia Mendes Silva
        "masculino", // André Sousa Oliveira
        "feminino",  // Helena Costa Rodrigues
        "masculino", // Nuno Pereira Almeida
        "feminino",  // Inês Gonçalves Teixeira
        "masculino", // Fábio Alves Ribeiro
        "feminino",  // Sara Fernandes Costa
        "masculino", // Gonçalo Silva Oliveira
        "feminino",  // Lara Rodrigues Ferreira
        "masculino", // José Pereira Almeida
        "feminino",  // Carolina Santos Ribeiro
        "masculino", // Rui Teixeira Oliveira
        "feminino",  // Ingrid Fernandes Costa
        "masculino", // Guilherme Almeida Barbosa
        "feminino",  // Tatiana Oliveira Silva
        "masculino", // Rafael Carvalho Pereira
        "feminino",  // Daniela Costa Rodrigues
        "masculino", // Leandro Santos Ribeiro
        "feminino",  // Clara Oliveira Almeida
        "masculino", // Bruno Pereira Costa
        "feminino",  // Mariana Rodrigues Gonçalves
        "masculino", // Tiago Silva Almeida
        "feminino",  // Isabela Ribeiro Teixeira
        "masculino", // Davi Almeida Costa
        "feminino",  // Larissa Teixeira Gonçalves
        "masculino", // Marcelo Fernandes Pereira
        "feminino",  // Fernanda Santos Oliveira
        "masculino", // Vinícius Pereira Costa
        "masculino"  // Lucas Alves Ribeiro
    )

    val idades = arrayOf(
        25,
        32,
        42,
        28,
        35,
        47,
        20,
        31,
        56,
        40,
        22,
        29,
        38,
        50,
        27,
        33,
        44,
        21,
        37,
        48,
        26,
        41,
        30,
        54,
        36,
        23,
        39,
        46,
        24,
        52,
        34,
        47,
        20,
        43,
        55,
        45,
        60,
        19,
        53,
        49,
        58,
        18,
        51,
        57,
        61,
        64,
        63,
        59,
        62,
        68,)

    val profissoesTI = arrayOf(
        "Desenvolvedor de Software",
        "Engenheiro de Software",
        "Analista de Sistemas",
        "Administrador de Redes",
        "Diretor em Arquitetura de Soluções",
        "Designer de Interface de Usuário (UI/UX)",
        "Engenheiro de Dados",
        "Cientista de Dados",
        "Analista de Segurança da Informação",
        "Administrador de Banco de Dados",
        "Especialista em Cloud Computing",
        "Analista de Qualidade de Software",
        "Gerente de Projetos de T.I",
        "Analista de Suporte Técnico",
        "Especialista em Redes e Telecomunicações",
        "Desenvolvedor Web",
        "Diretor de Business Intelligence",
        "Engenheiro de DevOps",
        "Analista de Business Analyst",
        "Especialista em Inteligência Artificial",
        "Administrador de Sistemas",
        "Especialista em Machine Learning",
        "Engenheiro de Site Reliability (SRE)",
        "Desenvolvedor Front-end",
        "Desenvolvedor Back-end",
        "Especialista em Cibersegurança",
        "Analista de Dados Empresariais",
        "Engenheiro de Redes",
        "Desenvolvedor Mobile",
        "Analista de Suporte ao Cliente",
        "Engenheiro de Redes e Segurança",
        "Especialista em Big Data",
        "Diretor de TI",
        "Analista de Infraestrutura de T.I",
        "Especialista em Realidade Virtual",
        "Engenheiro de Software de Jogos",
        "Desenvolvedor de Aplicativos Móveis",
        "Analista de Sistemas ERP",
        "Especialista em Sistemas Embarcados",
        "Especialista em Blockchain",
        "Administrador de Banco de Dados Oracle",
        "Analista de Dados de Negócios",
        "Analista de Integração de Sistemas",
        "Desenvolvedor Full-Stack",
        "Especialista em Business Intelligence",
        "Engenheiro de Dados de Negócios",
        "Administrador de Banco de Dados SQL Server",
        "Especialista em Engenharia de Dados",
        "Diretor de Engenharia de Dados",
        "Engenheiro de Dados de Nuvem"
    )

    val salarios = arrayOf(3500,
        4200,
        5100,
        4800,
        6300,
        3800,
        4900,
        5600,
        7200,
        3600,
        4500,
        5800,
        6000,
        4700,
        4300,
        5500,
        6800,
        7500,
        4000,
        5700,
        4100,
        4400,
        6200,
        5400,
        7000,
        4600,
        6600,
        5900,
        5200,
        5300,
        4800,
        6100,
        3900,
        6700,
        4800,
        4200,
        6800,
        7300,
        5700,
        4500,
        4000,
        5000,
        6400,
        3800,
        7600,
        6500,
        5100,
        5600,
        4900,
        7400
    )

//    nomes.forEach {
//        val primeiroNome =  it.split(" ")[0]
//        val primeiroSobrenome = it.split(" ")[1]
//        val segundoSobrenome = it.split(" ")[2]
//
//        println("----------------------------------------------------")
//        println("Primeiro nome: $primeiroNome")
//        println("Segundo nome: $primeiroSobrenome")
//        println("Terceiro nome: $segundoSobrenome")
//        println("----------------------------------------------------")
//    }
    println("=-=-=-=-=-=-=-=-=-=-HOMEM MAIS VELHO E MAIS NOVO=-=-=-=-=-=-=-=-=-=-=-")
    println()
//    Procurando o Homem mais velho e o homem mais novo
    var maisVelho = idades[0];
    var indexMaisVelho = 0
    var maisNovo = idades[0];
    var indexMaisNovo = 0;
    for(i in 0  ..  idades.size-1){
        if(sexos[i].equals("masculino") && idades[i] > maisVelho){
            maisVelho = idades[i];
            indexMaisVelho = i;
        }
        else if(sexos[i].equals("masculino") && idades[i] < maisNovo){
            maisNovo = idades[i];
            indexMaisNovo = i;
        }
    }
    println("${nomes[indexMaisVelho]} é o homem mais velho com $maisVelho anos." + "\n${nomes[indexMaisNovo]} é o homem o mais novo com $maisNovo anos." )
    println()

    println("=-=-=-=-=-=-=-=-=-=-MULHER MAIS VELHA E MAIS NOVA=-=-=-=-=-=-=-=-=-=-=-")
    println()

    //Procurando a mulher mais velha e a mulher mais nova
    var maisVelha = idades[1];
    var maisNova = idades[1];

    for(i in 0  ..  idades.size-1){
        if(sexos[i].equals("feminino") && idades[i] > maisVelha){
            maisVelha = idades[i];
            indexMaisVelho = i;
        }
        else if(sexos[i].equals("feminino") && idades[i] < maisNova){
            maisNova = idades[i];
            indexMaisNovo = i;
        }
    }
    println("${nomes[indexMaisVelho]} é a mulher mais velha com $maisVelho anos." + "\n${nomes[indexMaisNovo]} é a mulher mais nova com $maisNovo anos." )
    println()

    println("=-=-=-=-=-=-=-=-=-=-MÉDIA DE IDADES DOS HOMENS=-=-=-=-=-=-=-=-=-=-=-")
    println()

//Procurando a média das idades dos homens e das mulheres
    var auxIdades = 0;
    var qtdHomens = 0;
    var qtdMulheres = 0
    var qtdTotal = 0

    for(i in 0 .. sexos.size-1){
        if(sexos[i].equals("masculino")){
            auxIdades += idades[i];
            qtdHomens ++;
        }
    }
    println("A quantidade de homens é de : $qtdHomens")
    println("A soma das idades dos homens é de : ${auxIdades}")
    println("A média das idades dos homens é de : ${auxIdades / qtdHomens}")
    println()

    println("=-=-=-=-=-=-=-=-=-=-MÉDIA DE IDADES DAS MULHERES=-=-=-=-=-=-=-=-=-=-=-")
    println()
    for(i in 0 .. sexos.size-1){
        if(sexos[i].equals("feminino")){
            auxIdades += idades[i];
            qtdMulheres ++;
        }
    }
    println("A quantidade de mulheres é de : $qtdMulheres")
    println("A soma das idades das mulheres é de : ${auxIdades}")
    println("A média das idades das mulheres é de : ${auxIdades / qtdMulheres}")
    println()

    println("=-=-=-=-=-=-=-=-=-=-MÉDIA DE IDADES TOTAL=-=-=-=-=-=-=-=-=-=-=-")
    println()

    for(i in 0 .. sexos.size-1){
            auxIdades += idades[i];
            qtdTotal ++;
    }
    println("A quantidade de pessoas é de : $qtdTotal")
    println("A soma das idades das pessoas são de : ${auxIdades}")
    println("A média das idades das pessoas são de : ${auxIdades / qtdTotal}")
    println()

    println("=-=-=-=-=-=-=-=-=-=-Diretor com o maior salário=-=-=-=-=-=-=-=-=-=-=-")
    println()

    var biggestCompesation = 0
    var index = 0
    for(i in 0 .. profissoesTI.size-1){
        if(profissoesTI[i].contains("Diretor ") && salarios[i] > biggestCompesation){
            biggestCompesation = salarios[i]
            index = i
        }
    }
    println("O Diretor com o maior salário da empresa é : " + profissoesTI[index] + " : " + salarios[index]);
    println()

    println("=-=-=-=-=-=-=-=-=-=-Maior nome da empresa=-=-=-=-=-=-=-=-=-=-=-")
    println()

    var maiorNome = nomes[0]
    var tamanhoDoNome = nomes[0].length
    nomes.forEach {
        val counterLetters = it.length
        if(counterLetters > tamanhoDoNome){
            maiorNome = it;
            tamanhoDoNome = counterLetters
        }
    }
    println("O maior nome é: $maiorNome com $tamanhoDoNome letras")
    println()

    println("=-=-=-=-=-=-=-=-=-=-Pessoas com idade de 18 anos=-=-=-=-=-=-=-=-=-=-=-")
    println()

    var idadesIguaisA18: Array<String> = emptyArray()

    for(i in 0 .. idades.size-1){
        if(idades[i] === 18){
            idadesIguaisA18 = idadesIguaisA18.plus(nomes[i])
        }
    }

    idadesIguaisA18.forEach {
        println("$it tem 18 anos")
    }
    println()

    println("=-=-=-=-=-=-=-=-=-=-Nomes que começam com a letra A=-=-=-=-=-=-=-=-=-=-=-")
    println()

    var nomesComA: Array<String> = emptyArray()

    nomes.forEach {
        var splitName = it.split("");
        if(splitName[1].equals("A")){
            nomesComA = nomesComA.plus(it);
        }
    }

    nomesComA.forEach {
        println(it)
    }

    println("=============== F I M ==================")

}